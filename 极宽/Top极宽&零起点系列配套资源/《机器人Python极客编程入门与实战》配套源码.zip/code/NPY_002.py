from pyb import I2C

_24L64_ADDR = const(0x57)

class _24L64(object):
def __init__(self, i2c_num, i2c_addr=_24L64_ADDR, i2c_baud=100000):
        self.i2c_addr = i2c_addr
        self.i2c_buad = i2c_baud
        self.r = bytearray(2)
        self.w = bytearray(3)
        self.i2c = I2C(i2c_num, I2C.MASTER, baudrate = i2c_baud)

def read(self, addr):
        self.r[0] = addr//256
        self.r[1] = addr%256
        self.i2c.send(self.r, self.i2c_addr)
return self.i2c.recv(1, self.i2c_addr)[0]

def write(self, addr, dat):
        self.w[0] = addr//256
        self.w[1] = addr%256
        self.w[2] = dat
        self.i2c.send(self.w, self.i2c_addr)
