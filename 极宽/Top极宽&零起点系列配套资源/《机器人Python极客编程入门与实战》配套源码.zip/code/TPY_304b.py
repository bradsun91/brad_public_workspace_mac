 print('while')
while (K>0):
    _dataRead=u2.readall()
    if(1>0):
        x = accel.x()
        print("x=")
        print(x)
        if x > 10:
            xlights[0].on()
            xlights[1].off()
            u2.write('\x00\x05\x18YOU')
            #pyb.delay(1000)
            print('\x00\x01\x18YOU')
        elif x < -10:
            xlights[1].on()
            xlights[0].off()
            u2.write('\x00\x05\x18ZUO')
            print('\x00\x01\x18ZUO')
            #pyb.delay(1000)

        else:
            xlights[0].off()
            xlights[1].off()

        y = accel.y()
        print("y=")
        print(y)
        if y > 15:
            ylights[0].on()
            ylights[1].off()
            #u2.write('\x00\x05\x18HOU')
            #pyb.delay(1000)
            #print('\x00\x01\x18HOU')
        elif y < -15:
            ylights[1].on()
            ylights[0].off()
            u2.write('\x00\x05\x18QIAN')
            #pyb.delay(1000)
            print('\x00\x01\x18QIAN')
        else:
            ylights[0].off()
            ylights[1].off()

        pyb.delay(10)
