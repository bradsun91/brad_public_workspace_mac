import pyb
import time
from pyb import Pin

xlights = (pyb.LED(2), pyb.LED(3))
ylights = (pyb.LED(1), pyb.LED(4))
M0 = Pin('X1', Pin.OUT_PP)
accel = pyb.Accel()
i=0.0001
j=0.0000
while True:
	x = accel.x()
	print("x=")
	print(x)
	Y=x+20
	M0.high()
	time.sleep(i*Y)
	M0.low()
	time.sleep(i*Y)
	pyb.delay(12)

	if x > 0:
		xlights[0].on()
		xlights[1].off()
	elif x < 0:
		xlights[1].on()
		xlights[0].off()
	else:
		xlights[0].off()
		xlights[1].off()
