from HMC5883 import HMC5883

h = HMC5883(1)
while True:
    pyb.delay(500)
    print("%5d"%h.getX(),"%5d"%h.getY(),"%5d"%h.getZ())
