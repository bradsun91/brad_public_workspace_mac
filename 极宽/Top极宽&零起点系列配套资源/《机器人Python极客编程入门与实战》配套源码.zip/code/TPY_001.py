myled = pyb.LED(4)
myled.on()