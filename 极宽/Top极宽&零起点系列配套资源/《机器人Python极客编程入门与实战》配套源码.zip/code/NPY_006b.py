import pi

npi=pi.pi_t(1000)
npi=pi.pi_t(2000)
npi=pi.pi_t(5000)
