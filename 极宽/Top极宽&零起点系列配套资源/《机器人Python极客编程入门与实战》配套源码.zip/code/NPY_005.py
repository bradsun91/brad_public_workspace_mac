from pyb import ADC, Pin

adc = ADC(Pin('X9'))                        
while True:               
   dat = adc.read()                        
   pyb.LED(1).intensity(dat>>4)                                    
   print(dat)                  
   pyb.delay(200) 
