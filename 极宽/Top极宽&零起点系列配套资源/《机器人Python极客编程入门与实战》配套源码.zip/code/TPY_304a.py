import pyb
    
xlights = (pyb.LED(2), pyb.LED(3))
ylights = (pyb.LED(1), pyb.LED(4))

from pyb import UART
from pyb import Pin
#from ubinascii import hexlify
from ubinascii import *

accel = pyb.Accel()
u2 = UART(2, 9600)
i=0
K=1
