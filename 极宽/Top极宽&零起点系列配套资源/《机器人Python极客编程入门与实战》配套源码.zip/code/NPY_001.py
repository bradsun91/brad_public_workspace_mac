from pyb import Timer

ia = 1 
da = 1 
def fa(t): 
	global ia, da 
	if (ia==0)or(ia==255): 
			da=256-da 
		ia=(ia+da)%256 
	pyb.LED(3).intensity(ia) 

tm=Timer(1, freq=200, callback=fa)
