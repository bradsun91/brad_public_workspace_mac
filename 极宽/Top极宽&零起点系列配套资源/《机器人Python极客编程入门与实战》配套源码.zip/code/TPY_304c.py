 import pyb
    from pyb import UART
    from pyb import Pin
    from ubinascii import hexlify
    from ubinascii import *
    M1 = Pin('X1', Pin.OUT_PP)
    M3 = Pin('Y1', Pin.OUT_PP)
    u2 = UART(2, 9600)
    i=0
    K=1
